
import ad_map_access as ad

if __name__ == '__main__':
    ad.map.access.init("Town05.txt")

    # map matching
    mapMatching = ad.map.match.AdMapMatching()
    geoPoint = ad.map.point.GeoPoint()

    # GeoPoint(longitude:-0.000904582,latitude:0.000858925,altitude:0)
    geoPoint.latitude = ad.map.point.Latitude(-0.0014732377513161866) 
    geoPoint.longitude = ad.map.point.Longitude(-0.0008210678594053888) 
    geoPoint.altitude = ad.map.point.Altitude(0.0)

    mapMatchingResults = mapMatching.getMapMatchedPositions(
        geoPoint, ad.physics.Distance(13), ad.physics.Probability(0.5))

    if len(mapMatchingResults) > 0:
        pos = mapMatchingResults[0]
        lane = ad.map.lane.getLane(pos.lanePoint.paraPoint.laneId)
        print(f"laneId: {lane.id} with {len(lane.contactLanes)} contact lanes:")
        leftLaneInfo = lane.edgeRight
        pointECEObj = leftLaneInfo.ecefEdge
        print(pointECEObj[0].x)
        print(pointECEObj[0].y)
        print(pointECEObj[0].z)
        #print(lane)
        #print(f"leftEdge : {lane.edgeLeft} with {lane.id}")
